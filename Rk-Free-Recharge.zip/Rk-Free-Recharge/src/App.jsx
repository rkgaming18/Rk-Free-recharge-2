import React, { useState } from 'react';
import './App.css';

const prizes = [
  { label: '299 Recharge', color: 'bg-red-400' },
  { label: '2GB DATA', color: 'bg-green-400' },
  { label: '5GB DATA', color: 'bg-yellow-400' },
  { label: '1GB DATA', color: 'bg-blue-400' },
];

export default function App() {
  const [selectedPrize, setSelectedPrize] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const spin = () => {
    const randomIndex = Math.floor(Math.random() * prizes.length);
    setTimeout(() => {
      setSelectedPrize(prizes[randomIndex]);
      setShowModal(true);
    }, 1000);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-3xl font-bold mb-6">Spin the Wheel</h1>
      <div className="grid grid-cols-2 gap-4 mb-6">
        {prizes.map((prize, i) => (
          <div key={i} className={`p-6 rounded-lg text-white text-center ${prize.color}`}>
            {prize.label}
          </div>
        ))}
      </div>
      <button onClick={spin} className="px-4 py-2 bg-black text-white rounded-full">Spin</button>
      {showModal && selectedPrize && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-6 rounded-lg text-center">
            <h2 className="text-xl font-bold">🎁 আপুনি জিকাৰিছে:</h2>
            <p className="my-2 text-lg">{selectedPrize.label}</p>
            <p className="mb-4 text-sm">এই উপহাৰটো লাভ কৰিবলৈ তলৰ কামটো সম্পূৰ্ণ কৰক:</p>
            <a href="https://instagram.com/akhim_b18" target="_blank" className="text-blue-500 underline">
              Follow on Instagram
            </a>
            <button onClick={() => setShowModal(false)} className="mt-4 block w-full bg-red-500 text-white py-1 rounded">বন্ধ কৰক</button>
          </div>
        </div>
      )}
    </div>
  );
}
